<?php $__env->startSection('content'); ?>
<div class="p-4 bg-white rounded shadow-sm mb-4 border-start border-4 border-primary">
    <h2 class="mb-1">Olá, <?php echo e($usuario->name); ?>!</h2>
    <p class="text-muted mb-0">Bem-vindo ao painel principal da oficina mecânica. Utilize os atalhos abaixo para navegar.</p>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <h5 class="card-title">Clientes (<?php echo e($totalClientes); ?>)</h5>
                <p class="card-text text-muted">Gerencie o cadastro de clientes com busca rápida e proteção de CPF (LGPD).</p>
                <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-primary">Acessar Clientes</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <h5 class="card-title">Veículos (<?php echo e($totalVeiculos); ?>)</h5>
                <p class="card-text text-muted">Cadastre veículos e associe cada automóvel ao seu respectivo proprietário.</p>
                <a href="<?php echo e(route('veiculos.index')); ?>" class="btn btn-primary">Acessar Veículos</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <h5 class="card-title">Agendamentos (<?php echo e($totalAgendamentos); ?>)</h5>
                <p class="card-text text-muted">Consulte horários ordenados por data e reagende serviços facilmente.</p>
                <a href="<?php echo e(route('agendamentos.index')); ?>" class="btn btn-primary">Acessar Agendamentos</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\44648743806\Desktop\oficina_oficial\resources\views/principal.blade.php ENDPATH**/ ?>