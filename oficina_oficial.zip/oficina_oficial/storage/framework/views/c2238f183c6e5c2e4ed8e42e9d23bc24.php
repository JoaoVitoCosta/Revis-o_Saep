<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Gerenciamento de Clientes</h3>
    <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-success">+ Novo Cliente</a>
</div>

<form action="<?php echo e(route('clientes.index')); ?>" method="GET" class="row g-2 mb-4">
    <div class="col-md-8">
        <input type="text" name="busca" value="<?php echo e($termo); ?>" class="form-control" placeholder="Digite o termo para buscar (nome, CPF, telefone ou e-mail)...">
    </div>
    <div class="col-md-4">
        <button type="submit" class="btn btn-primary">Confirmar Busca</button>
        <?php if($termo): ?>
            <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-secondary">Limpar</a>
        <?php endif; ?>
    </div>
</form>

<div class="table-responsive bg-white rounded shadow-sm">
    <table class="table table-hover align-middle mb-0">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>CPF (Protegido LGPD)</th>
                <th>Telefone</th>
                <th>E-mail</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($cliente->id); ?></td>
                <td class="fw-semibold"><?php echo e($cliente->nome); ?></td>
                <td><?php echo e($cliente->cpf); ?></td>
                <td><?php echo e($cliente->telefone); ?></td>
                <td><?php echo e($cliente->email ?? '-'); ?></td>
                <td>
                    <a href="<?php echo e(route('clientes.edit', $cliente)); ?>" class="btn btn-sm btn-warning">Editar</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center py-4 text-muted">Nenhum cliente encontrado para o termo informado.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\44648743806\Desktop\oficina_oficial\resources\views/clientes/index.blade.php ENDPATH**/ ?>