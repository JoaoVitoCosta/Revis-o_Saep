<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Oficina Mecânica - Sistema de Gestão</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex flex-column min-vh-100">
    <?php if(auth()->guard()->check()): ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4 shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?php echo e(route('principal')); ?>">Oficina SENAI</a>
            <div class="collapse navbar-collapse show">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('principal') ? 'active' : ''); ?>" href="<?php echo e(route('principal')); ?>">Início</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('clientes.*') ? 'active' : ''); ?>" href="<?php echo e(route('clientes.index')); ?>">Clientes</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('veiculos.*') ? 'active' : ''); ?>" href="<?php echo e(route('veiculos.index')); ?>">Veículos</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('agendamentos.*') ? 'active' : ''); ?>" href="<?php echo e(route('agendamentos.index')); ?>">Agendamentos</a></li>
                </ul>
                <span class="navbar-text text-white me-3">
                    Usuário: <strong><?php echo e(Auth::user()->name); ?></strong>
                </span>
                <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-danger btn-sm">Sair</button>
                </form>
            </div>
        </div>
    </nav>
    <?php endif; ?>

    <main class="container flex-grow-1">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($erro); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="bg-white text-center text-muted py-3 mt-5 border-top">
        <small>Sistema de Gestão de Oficina Mecânica &copy; <?php echo e(date('Y')); ?> - Conformidade LGPD</small>
    </footer>
</body>
</html>
<?php /**PATH C:\Users\44648743806\Desktop\oficina_oficial\resources\views/layouts/app.blade.php ENDPATH**/ ?>