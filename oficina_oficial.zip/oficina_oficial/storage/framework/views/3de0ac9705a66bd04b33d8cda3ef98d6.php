<?php $__env->startSection('content'); ?>
<div class="card shadow-sm col-md-6 mx-auto">
    <div class="card-header bg-dark text-white">
        <h5 class="mb-0">Novo Agendamento</h5>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('agendamentos.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label">Cliente *</label>
                <select name="cliente_id" class="form-select" required>
                    <option value="">Selecione o cliente...</option>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nome); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Veículo *</label>
                <select name="veiculo_id" class="form-select" required>
                    <option value="">Selecione o veículo...</option>
                    <?php $__currentLoopData = $veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $veiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($veiculo->id); ?>"><?php echo e($veiculo->placa); ?> - <?php echo e($veiculo->marca); ?> <?php echo e($veiculo->modelo); ?> (Proprietário: <?php echo e($veiculo->cliente->nome); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Data e Hora do Agendamento *</label>
                <input type="datetime-local" name="data_agendamento" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Descrição do Serviço *</label>
                <input type="text" name="descricao_servico" class="form-control" placeholder="Ex: Troca de óleo e filtros" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Status *</label>
                <select name="status" class="form-select">
                    <option value="Pendente">Pendente</option>
                    <option value="Em Andamento">Em Andamento</option>
                    <option value="Concluido">Concluido</option>
                    <option value="Cancelado">Cancelado</option>
                </select>
            </div>

            <div class="d-flex justify-content-between">
                <a href="<?php echo e(route('agendamentos.index')); ?>" class="btn btn-secondary">Voltar</a>
                <button type="submit" class="btn btn-success">Confirmar Agendamento</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\44648743806\Desktop\oficina_oficial\resources\views/agendamentos/form.blade.php ENDPATH**/ ?>