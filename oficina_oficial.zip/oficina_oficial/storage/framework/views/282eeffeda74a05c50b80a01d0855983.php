<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Gerenciamento de Veículos</h3>
    <a href="<?php echo e(route('veiculos.create')); ?>" class="btn btn-success">+ Novo Veículo</a>
</div>

<div class="table-responsive bg-white rounded shadow-sm">
    <table class="table table-hover align-middle mb-0">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Placa</th>
                <th>Marca / Modelo</th>
                <th>Ano</th>
                <th>Cliente Proprietário</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $veiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($veiculo->id); ?></td>
                <td><span class="badge bg-secondary fs-6"><?php echo e($veiculo->placa); ?></span></td>
                <td><?php echo e($veiculo->marca); ?> - <?php echo e($veiculo->modelo); ?></td>
                <td><?php echo e($veiculo->ano); ?></td>
                <td><?php echo e($veiculo->cliente->nome); ?> (<?php echo e($veiculo->cliente->telefone); ?>)</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center py-4 text-muted">Nenhum veículo cadastrado.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\44648743806\Desktop\oficina_oficial\resources\views/veiculos/index.blade.php ENDPATH**/ ?>