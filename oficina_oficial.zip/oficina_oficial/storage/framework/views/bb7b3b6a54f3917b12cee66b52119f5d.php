<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Agendamentos (Ordenados por Data)</h3>
    <a href="<?php echo e(route('agendamentos.create')); ?>" class="btn btn-success">+ Novo Agendamento</a>
</div>

<div class="table-responsive bg-white rounded shadow-sm">
    <table class="table table-hover align-middle mb-0">
        <thead class="table-dark">
            <tr>
                <th>Dia / Horário</th>
                <th>Serviço</th>
                <th>Status</th>
                <th>Dados Completos do Cliente</th>
                <th>Dados Completos do Veículo</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $agendamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="fw-bold text-primary"><?php echo e($ag->data_agendamento->format('d/m/Y H:i')); ?></td>
                <td><?php echo e($ag->descricao_servico); ?></td>
                <td><span class="badge bg-info text-dark"><?php echo e($ag->status); ?></span></td>
                <td>
                    <strong><?php echo e($ag->cliente->nome); ?></strong><br>
                    <small class="text-muted">CPF: <?php echo e($ag->cliente->cpf); ?> | Tel: <?php echo e($ag->cliente->telefone); ?> | E-mail: <?php echo e($ag->cliente->email ?? '-'); ?></small>
                </td>
                <td>
                    <strong><?php echo e($ag->veiculo->marca); ?> <?php echo e($ag->veiculo->modelo); ?></strong><br>
                    <small class="text-muted">Placa: <?php echo e($ag->veiculo->placa); ?> | Ano: <?php echo e($ag->veiculo->ano); ?></small>
                </td>
                <td>
                    <a href="<?php echo e(route('agendamentos.edit', $ag)); ?>" class="btn btn-sm btn-warning">Atualizar Data</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center py-4 text-muted">Nenhum agendamento registrado.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\44648743806\Desktop\oficina_oficial\resources\views/agendamentos/index.blade.php ENDPATH**/ ?>